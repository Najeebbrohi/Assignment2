/////////////////// 1 Assignmnet /////////////////

function Add(num1){
    return function(num2){
        console.log(num1 + num2);
    }
}

/////////////////// 2 Assignment //////////////////

let array = ["Ali", "Khan", "Amir"];
searchArray(2, "Amir");
function searchArray(array, value){
	if(array.value === 0){
		return false;
	}
	else if(array[0] === value)
	{
		return true;
	}
	else
	{
		return searchArray(array.slice(0,2), value);
	}
}

////////////////// 3 Assignment /////////////////

function newPara(text) {
    let para = document.querySelector("body");
    para.innerHTML = "<p>"+text+"</p>";
}
console.log(newPara("This is a new  Paragraph"));


////////////////// 4 Assignment /////////////////

function newFun(text) {
    let li = document.getElementById("ul");
    li.innerHTML = "<li>"+text+"</li>";  
}

setInterval(function() {
    newFun("Li adding");
}, 1000);


///////////// 5 Assignment //////////////////

let para1 = document.getElementById("para1");
para1.style.backgroundColor = "red";
para1.style.color = "white";
para1.style.fontSize ="20px";


////////////// 6 Assignment ///////////////////

function myObj(key, obj) {
    let objectString = JSON.stringify(obj);
    localStorage.setItem(key, objectString);
  }

let myObjt = { name: "Najeeb", age: 22 };
myObj("myObj",myObjt);
console.log(myObjt)



////////////// 7 Assignment /////////////////////

function getLocalStorage(key) {
    let objString = localStorage.getItem(key);
    return JSON.parse(objString);
  }

  let myData = getLocalStorage("Najeeb");
  console.log(myData);

